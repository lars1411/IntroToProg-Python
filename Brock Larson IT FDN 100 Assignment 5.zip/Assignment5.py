'''
Developer: Brock Larson
Description: Assignment 5
Objective:
1.	Create a text file called Todo.txt using the following data:
Clean House,low
Pay Bills,high
2.	When the program starts, load each row of data from the ToDo.txt text
file into a Python dictionary. (The data will be stored like a row in a table.)
Tip: You can use a for loop to read a single line of text from the file and
then place the data into a new dictionary object.

3.	After you get the data in a Python dictionary, Add the new dictionary “row”
into a Python list object (now the data will be managed as a table).

4.	Display the contents of the List to the user.

5.	Allow the user to Add or Remove tasks from the list using numbered choices.
 Something like this would work:

    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program

6.	Save the data from the table into the Todo.txt file when the program exits.
'''



dicToDo = {} #Create Dictionary for data in "ToDo_txt"
lstToDo = [] #Create List for data in "ToDo_txt"

#Read Data from ToDo_txt to a list
def ReadFile():
    todoFile = open("C:\\_PythonClass\\ToDo.txt","r") #opens file with name of "ToDo_txt" for reading
    for line in todoFile:
        strTask = str(line.split(",")[0]).strip()
        strPri = str(line.split(",")[1]).strip()
        dicToDo = {"task":strTask, "pri":strPri}
        lstToDo.append(dicToDo)
    todoFile.close()

#Show Current Data
def Option1():
    print("\n" + "Your Current Data is:")
    for row in lstToDo:
        strPrintValue = ""
        for key, value in row.items():
            strPrintValue += (value + ",")
        print(strPrintValue.strip(","), end="")
        print("\n", end="")
    print("\n")

#Add a new item
def Option2():
    while(True):
        strTask = input("\n" + 'Enter New Task or "Done"' + "\n")
        if strTask.lower() == "done":
            print("\n")
            break
        strPri = input("Enter Priority" + "\n")

        dicToDo = {"task":strTask, "pri":strPri} #New row of data

        lstToDo.append(dicToDo) #Add new row of data to table

#Remove a row
def Option3():
    while(True):
        Option1()
        print("You have " + str(len(lstToDo)) + " Entries")
        strRemove = input('Enter the number of the row to remove or "Done" ')
        if strRemove.lower() == "done":
            print("\n")
            break
        del lstToDo[(int(strRemove))-1]
        print("Row " + strRemove + " Removed" + "\n")

#Save Data to File
def Option4():
    # While Loop for saving
    while(True):
        strFileSave = input("\n" + "Would you like to Save data to Todo.txt (y/n) ")
        if strFileSave.lower() == "y":
            # Write Data to File, HomeInventory.txt
            # Open file HomeInventory.txt for editing
            todoFile = open("C:\\_PythonClass\\ToDo.txt", "w")
            for row in lstToDo:
                strPrintValue = ""
                for key, value in row.items():
                    # For item in row:
                    strPrintValue += (value + ",")
                todoFile.write(strPrintValue.strip(",") + "\n")
            # Close and Save file
            todoFile.close()
            print("Data Saved." + "\n")
            break
        elif strFileSave.lower() == "n":
            print("\n")
            break
        else:
            print('Please Enter "y" or "n"')

def Main():
    ReadFile()
    while(True):
        print("Menu of Options")
        print("1) Show Current Data")
        print("2) Add a new item")
        print("3) Remove an existing item")
        print("4) Save Data to File")
        print("5) Exit Program")
        strMenu = input("Select ")

        if strMenu == "1": Option1()
        elif strMenu == "2": Option2()
        elif strMenu == "3": Option3()
        elif strMenu == "4": Option4()
        elif strMenu == "5": exit()

Main()