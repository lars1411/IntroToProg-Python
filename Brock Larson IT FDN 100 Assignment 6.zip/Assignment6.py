'''
Developer: Brock Larson
Description: Assignment 6
Objective:
This project is very like the last one, but this time you will place the code you
created for working with your ToDo.txt file into Functions and a Class
'''


#-- Inputs --#
def Main():
    lstToDo = []  # Create List for data in "ToDo_txt"
    TodoProcessing.ReadFile(lstToDo)
    while(True):
        print("Menu of Options")
        print("1) Show Current Data")
        print("2) Add a new item")
        print("3) Remove an existing item")
        print("4) Save Data to File")
        print("5) Exit Program")
        strMenu = input("Select ")

        if strMenu == "1": TodoOutput.ShowData(lstToDo)
        elif strMenu == "2": TodoProcessing.AddData(lstToDo)
        elif strMenu == "3": TodoProcessing.DeleteData(lstToDo)
        elif strMenu == "4": TodoOutput.SaveData(lstToDo)
        elif strMenu == "5": exit()

#-- Processing --#
class TodoProcessing (object):
    # Read Data from ToDo_txt to a list
    @staticmethod
    def ReadFile(lstToDo):
        todoFile = open("C:\\_PythonClass\\ToDo.txt","r") #opens file with name of "ToDo_txt" for reading
        for line in todoFile:
            strTask = str(line.split(",")[0]).strip()
            strPri = str(line.split(",")[1]).strip()
            dicToDo = {"task":strTask, "pri":strPri}
            lstToDo.append(dicToDo)
        todoFile.close()

    #Add a new item
    @staticmethod
    def AddData(lstToDo):
        while(True):
            strTask = input("\n" + 'Enter New Task or "Done"' + "\n")
            if strTask.lower() == "done":
                print("\n")
                break
            strPri = input("Enter Priority" + "\n")

            dicToDo = {"task":strTask, "pri":strPri} #New row of data

            lstToDo.append(dicToDo) #Add new row of data to table

    #Remove a row
    @staticmethod
    def DeleteData(lstToDo):
        while(True):
            TodoOutput.ShowData(lstToDo)
            print("You have " + str(len(lstToDo)) + " Entries")
            strRemove = input('Enter the number of the row to remove or "Done" ')
            if strRemove.lower() == "done":
                print("\n")
                break
            try:
                del lstToDo[(int(strRemove))-1]
                print("Row " + strRemove + " Removed" + "\n")
            except:
                print("That row doesn't exist please enter 1 through " + str(len(lstToDo)))

#-- Outputs --#
class TodoOutput(object):
   # Show Current Data
    @staticmethod
    def ShowData(lstToDo):
        print("\n" + "Your Current Data is:")
        for row in lstToDo:
            strPrintValue = ""
            for key, value in row.items():
                strPrintValue += (value + ",")
            print(strPrintValue.strip(","), end="")
            print("\n", end="")
        print("\n")

    #Save Data to File
    @staticmethod
    def SaveData(lstToDo):
        # While Loop for saving
        while(True):
            strFileSave = input("\n" + "Would you like to Save data to Todo.txt (y/n) ")
            if strFileSave.lower() == "y":
                # Write Data to File, Todo_txt
                # Open file Todo_txt for writing
                todoFile = open("C:\\_PythonClass\\ToDo.txt", "w")
                for row in lstToDo:
                    strPrintValue = ""
                    for key, value in row.items():
                        # For item in row:
                        strPrintValue += (value + ",")
                    todoFile.write(strPrintValue.strip(",") + "\n")
                # Close and Save file
                todoFile.close()
                print("Data Saved." + "\n")
                break
            elif strFileSave.lower() == "n":
                print("\n")
                break
            else:
                print('Please Enter "y" or "n"')


Main()